-- AlterTable
ALTER TABLE "Study" ADD COLUMN     "name" TEXT;
