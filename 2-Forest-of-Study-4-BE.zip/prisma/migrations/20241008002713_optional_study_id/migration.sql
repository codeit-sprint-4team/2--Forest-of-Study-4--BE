-- AlterTable
ALTER TABLE "CompletedHabit" ALTER COLUMN "studyId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "Habit" ALTER COLUMN "studyId" DROP NOT NULL;
